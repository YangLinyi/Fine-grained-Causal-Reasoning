import torch
from transformers import BartTokenizer, T5Tokenizer


class BartConfig(object):
    base_path = '../../dataset/qa/'
    train_data_path = base_path + 'qa_dataset_train.json'
    dev_data_path = base_path + 'qa_dataset_dev.json'
    test_data_path = base_path + 'qa_dataset_test.json'

    device = 'cuda' if torch.cuda.is_available() else 'cpu'
    model = 'facebook/bart-base'
    model_name = 'bart-base'
    tokenizer = BartTokenizer.from_pretrained(model)
    lr = 1e-5
    train_batch_size = 4
    batch_accum = 8
    test_batch_size = 32
    num_epoch = 7

    model_save_path = './ckp/' + model_name + '.ckp'


class BartLargeConfig(object):
    base_path = '../../dataset/qa/'
    train_data_path = base_path + 'qa_dataset_train.json'
    dev_data_path = base_path + 'qa_dataset_dev.json'
    test_data_path = base_path + 'qa_dataset_test.json'

    device = 'cuda' if torch.cuda.is_available() else 'cpu'
    model = 'facebook/bart-large'
    model_name = 'bart-large'
    tokenizer = BartTokenizer.from_pretrained(model)
    lr = 1e-5
    train_batch_size = 4
    batch_accum = 8
    test_batch_size = 32
    num_epoch = 7

    model_save_path = './ckp/' + model_name + '.ckp'


class T5SmallConfig(object):
    base_path = '../../dataset/qa/'
    train_data_path = base_path + 'qa_dataset_train.json'
    dev_data_path = base_path + 'qa_dataset_dev.json'
    test_data_path = base_path + 'qa_dataset_test.json'

    device = 'cuda' if torch.cuda.is_available() else 'cpu'
    model = 't5-small'
    tokenizer = T5Tokenizer.from_pretrained(model)
    lr = 1e-5
    train_batch_size = 2
    batch_accum = 16
    test_batch_size = 32
    num_epoch = 7

    model_save_path = './ckp/' + model + '.ckp'


class T5Config(object):
    base_path = '../../dataset/qa/'
    train_data_path = base_path + 'qa_dataset_train.json'
    dev_data_path = base_path + 'qa_dataset_dev.json'
    test_data_path = base_path + 'qa_dataset_test.json'

    device = 'cuda' if torch.cuda.is_available() else 'cpu'
    model = 't5-base'
    tokenizer = T5Tokenizer.from_pretrained(model)
    lr = 1e-5
    train_batch_size = 2
    batch_accum = 16
    test_batch_size = 32
    num_epoch = 7

    model_save_path = './ckp/' + model + '.ckp'


class T5LargeConfig(object):
    base_path = '../../dataset/qa/'
    train_data_path = base_path + 'qa_dataset_train.json'
    dev_data_path = base_path + 'qa_dataset_dev.json'
    test_data_path = base_path + 'qa_dataset_test.json'

    device = 'cuda' if torch.cuda.is_available() else 'cpu'
    model = 't5-large'
    tokenizer = T5Tokenizer.from_pretrained(model)
    lr = 1e-5
    train_batch_size = 1
    batch_accum = 32
    test_batch_size = 32
    num_epoch = 7

    model_save_path = './ckp/' + model + '.ckp'
