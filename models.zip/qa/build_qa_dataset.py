import json
import random
from tqdm import tqdm

from transformers import BertTokenizerFast

tokenizer = BertTokenizerFast.from_pretrained('bert-base-cased')


def clean_content(input_str):
    time_reps = ['7 Jul 2021 05:00, UTC', '2 Jun 2021 05:00, UTC']
    single_reps = ['‘', '’']
    dual_reps = ['“', '”']

    for rep in single_reps:
        input_str = input_str.replace(rep, "'")
    for rep in dual_reps:
        input_str = input_str.replace(rep, '"')
    for rep in time_reps:
        input_str = input_str.replace(rep, ' ')
    return input_str


def create_contents():
    part1 = "Business Description"
    part2 = "Analyst Note"
    part3 = "Business Strategy & Outlook"
    part4 = "Economic Moat"
    part5 = "Fair Value and Profit Drivers"
    part6 = "Risk and Uncertainty"
    part7 = "Bulls Say"
    part8 = "Bears Say"
    parts = [part1, part2, part3, part4, part5, part6, part7, part8]

    contents = []

    j = json.load(open('result_without_analyst.json', 'r', encoding='utf8'))

    for key in j:
        outlook = j[key][part3][0]
        moat = j[key][part4][0]
        fair = j[key][part5][0]
        risk = j[key][part6][0]
        content = outlook + moat + fair + risk
        content = clean_content(content)
        contents.append(content)

    return contents


def gen_question_and_answer(event_a, event_b, relation):
    def gen_cause(event_a, event_b):
        question = 'What will happen if ' + event_a + '?'
        answer = event_b
        return question, answer

    def gen_cause_by(event_a, event_b):
        # question = 'What will cause ' + event_a + '?'
        question = 'Why ' + event_a + '?'
        answer = event_b
        return question, answer

    def gen_enable(event_a, event_b):
        # question = 'What happens with the help of ' + event_a + '?'
        question = 'Why ' + event_a + ' is useful?'
        answer = event_b
        return question, answer

    def gen_enable_by(event_a, event_b):
        question = 'What can help to ' + event_a + '?'
        answer = event_b
        return question, answer

    def gen_prevent(event_a, event_b):
        question = 'What will be prevented if ' + event_a + '?'
        answer = event_b
        return question, answer

    def gen_prevent_by(event_a, event_b):
        question = 'What will prevent ' + event_a + '?'
        answer = event_b
        return question, answer

    if relation == 'cause':
        question, answer = gen_cause(event_a, event_b) if random.randint(0, 1) == 0 else gen_cause_by(event_b, event_a)
    elif relation == 'cause_by':
        question, answer = gen_cause_by(event_a, event_b) if random.randint(0, 1) == 0 else gen_cause(event_b, event_a)
    elif relation == 'enable':
        question, answer = gen_enable(event_a, event_b) if random.randint(0, 1) == 0 else gen_enable_by(event_b,
                                                                                                        event_a)
    elif relation == 'enable_by':
        question, answer = gen_enable_by(event_a, event_b) if random.randint(0, 1) == 0 else gen_enable(event_b,
                                                                                                        event_a)
    elif relation == 'prevent':
        question, answer = gen_prevent(event_a, event_b) if random.randint(0, 1) == 0 else gen_prevent_by(event_b,
                                                                                                          event_a)
    elif relation == 'prevent_by':
        question, answer = gen_prevent_by(event_a, event_b) if random.randint(0, 1) == 0 else gen_prevent(event_b,
                                                                                                          event_a)
    else:
        question, answer = None, None
    return question, answer


def find_start_end_index(context, event):
    # try:
    start_index = context.index(event)
    end_index = start_index + len(event)
    return [start_index, end_index]
    # except Exception as e:
    #     print(context)


def find_single_context(causal_sentence, event_a, event_b, relation, contents):
    def find_next(index, ss):
        for i in range(5, 1, -1):
            context = ' '.join(ss[index: min(len(ss), index + i)])
            tokens = tokenizer(context)['input_ids']
            if len(tokens) < 450:
                return context
        return ss[index]

    def find_prev(index, ss):
        for i in range(5, 1, -1):
            context = ' '.join(ss[max(0, index - i): index + 1])
            tokens = tokenizer(context)['input_ids']
            if len(tokens) < 450:
                return context
        return ss[index]

    def find_prev_and_next(index, ss):
        for i in range(3, 1, -1):
            context = ' '.join(ss[max(0, index - i): min(len(ss), index + i)])
            tokens = tokenizer(context)['input_ids']
            if len(tokens) < 450:
                return context
        return ss[index]

    for content in contents:
        content = content.replace('U.S.', 'US')
        content = content.replace('U.K.', 'UK')
        if causal_sentence in content:
            ss = content.split('. ')
            ss = [' '.join(s.split()) + '.' for s in ss][:-1]
            for index, s in enumerate(ss):
                if s == causal_sentence:
                    ri = random.randint(0, 2)

                    # 作为起始句，则向后再找四句
                    if index == 0:
                        ri = 0
                    # 作为最后一句，则向前再找四句
                    elif index == len(ss) - 1:
                        ri = 1

                    if ri == 0:
                        context = find_next(index, ss)
                    elif ri == 1:
                        context = find_prev(index, ss)
                    else:
                        context = find_prev_and_next(index, ss)

                    question, answer = gen_question_and_answer(event_a, event_b, relation)
                    answer_index = find_start_end_index(context, answer)

                    return context, question, answer_index
    return None, None, None


def find_cross_context(sentence, event_a, event_b, relation):
    question, answer = gen_question_and_answer(event_a, event_b, relation)
    answer_index = find_start_end_index(sentence, answer)
    return sentence, question, answer_index


def init_dataset(json_data):
    data = []
    for item in json_data:
        sentence = item['info']
        causals = item['labelData']
        causal_set = set()
        causal_event_type_dict = dict()
        events = set()
        for causal in causals:
            causal_type = causal['type']
            reasons = causal['reason']
            results = causal['result']
            for reason_index in reasons:
                for result_index in results:
                    reason = sentence[reason_index[0]:reason_index[1]]
                    result = sentence[result_index[0]:result_index[1]]
                    causal_set.add((reason, result))
                    causal_event_type_dict[(reason, result)] = causal_type
                    events.add(reason)
                    events.add(result)
        for event_a in events:
            for event_b in events:
                if event_a != event_b:
                    # filter inverse event-pair
                    if sentence.index(event_a) < sentence.index(event_b):
                        if (event_a, event_b) in causal_set:
                            label = causal_event_type_dict[(event_a, event_b)]
                            data.append((sentence, event_a, event_b, label))
                        elif (event_b, event_a) in causal_set:
                            label = causal_event_type_dict[(event_b, event_a)] + '_by'
                            data.append((sentence, event_a, event_b, label))
    return data


def build_qa():
    qa_dataset = []  # [context, question, answer]
    contents = create_contents()
    j = json.load(open('event_dataset.json', 'r', encoding='utf8'))
    data = init_dataset(j)
    for item in tqdm(data):
        sentence = item[0]
        event_a = item[1]
        event_a = event_a.strip()
        event_b = item[2]
        event_b = event_b.strip()
        relation = item[3]
        if '. ' in sentence:
            context, question, answer_index = find_cross_context(sentence, event_a, event_b, relation)
        else:
            context, question, answer_index = find_single_context(sentence, event_a, event_b, relation, contents)
        if context is not None and question is not None and answer_index is not None:
            qa_dataset.append([context, question, answer_index])
        # break

    all_qa = []
    for index, qa in enumerate(qa_dataset):
        qa_id = index
        context = qa[0]
        question = qa[1]
        answer_index = qa[2]
        # answer = context[answer_index[0]:answer_index[1]]
        all_qa.append({'qid': qa_id, 'context': context, 'question': question, 'answer': answer_index})
    json.dump(all_qa, open('qa_dataset_new.json', 'w', encoding='utf8'))


if __name__ == '__main__':
    build_qa()
    # j = json.load(open('qa_dataset.json'))
    # pass
