import torch
from transformers import BertTokenizerFast, RobertaTokenizerFast, BartTokenizerFast


class BertConfig(object):
    base_path = '../../dataset/qa/'
    train_data_path = base_path + 'qa_dataset_train.json'
    dev_data_path = base_path + 'qa_dataset_dev.json'
    test_data_path = base_path + 'qa_dataset_test.json'

    device = 'cuda' if torch.cuda.is_available() else 'cpu'
    model = 'bert-base-cased'
    tokenizer = BertTokenizerFast.from_pretrained(model)

    lr = 1e-5
    train_batch_size = 4
    batch_accum = 8
    test_batch_size = 32
    num_epoch = 7

    model_save_path = './ckp/' + model + '.ckp'


class BertLargeConfig(object):
    base_path = '../../dataset/qa/'
    train_data_path = base_path + 'qa_dataset_train.json'
    dev_data_path = base_path + 'qa_dataset_dev.json'
    test_data_path = base_path + 'qa_dataset_test.json'

    device = 'cuda' if torch.cuda.is_available() else 'cpu'
    model = 'bert-large-cased'
    tokenizer = BertTokenizerFast.from_pretrained(model)

    lr = 1e-5
    train_batch_size = 4
    batch_accum = 8
    test_batch_size = 32
    num_epoch = 7

    model_save_path = './ckp/' + model + '.ckp'


class RobertaConfig(object):
    base_path = '../../dataset/qa/'
    train_data_path = base_path + 'qa_dataset_train.json'
    dev_data_path = base_path + 'qa_dataset_dev.json'
    test_data_path = base_path + 'qa_dataset_test.json'

    device = 'cuda' if torch.cuda.is_available() else 'cpu'
    model = 'roberta-base'
    tokenizer = RobertaTokenizerFast.from_pretrained(model)

    lr = 1e-5
    train_batch_size = 4
    batch_accum = 8
    test_batch_size = 32
    num_epoch = 7

    model_save_path = './ckp/' + model + '.ckp'


class RobertaLargeConfig(object):
    base_path = '../../dataset/qa/'
    train_data_path = base_path + 'qa_dataset_train.json'
    dev_data_path = base_path + 'qa_dataset_dev.json'
    test_data_path = base_path + 'qa_dataset_test.json'

    device = 'cuda' if torch.cuda.is_available() else 'cpu'
    model = 'roberta-large'
    tokenizer = RobertaTokenizerFast.from_pretrained(model)

    lr = 1e-5
    train_batch_size = 4
    batch_accum = 8
    test_batch_size = 32
    num_epoch = 7

    model_save_path = './ckp/' + model + '.ckp'


class RobertaSQuADConfig(object):
    base_path = '../../dataset/qa/'
    train_data_path = base_path + 'qa_dataset_train.json'
    dev_data_path = base_path + 'qa_dataset_dev.json'
    test_data_path = base_path + 'qa_dataset_test.json'

    device = 'cuda' if torch.cuda.is_available() else 'cpu'
    model = 'deepset/roberta-base-squad2'
    model_name = 'roberta-base-squad2'
    tokenizer = RobertaTokenizerFast.from_pretrained(model)

    lr = 1e-5
    train_batch_size = 4
    batch_accum = 8
    test_batch_size = 32
    num_epoch = 7

    model_save_path = './ckp/' + model_name + '.ckp'


class RobertaSQuADLargeConfig(object):
    base_path = '../../dataset/qa/'
    train_data_path = base_path + 'qa_dataset_train.json'
    dev_data_path = base_path + 'qa_dataset_dev.json'
    test_data_path = base_path + 'qa_dataset_test.json'

    device = 'cuda' if torch.cuda.is_available() else 'cpu'
    model = 'deepset/roberta-large-squad2'
    model_name = 'roberta-large-squad2'
    tokenizer = RobertaTokenizerFast.from_pretrained(model)

    lr = 1e-5
    train_batch_size = 4
    batch_accum = 8
    test_batch_size = 32
    num_epoch = 7

    model_save_path = './ckp/' + model_name + '.ckp'
